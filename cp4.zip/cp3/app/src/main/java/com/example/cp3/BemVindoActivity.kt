// BemVindoActivity.kt
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myapp.models.Usuario
import com.example.myapp.network.ApiClient
import kotlinx.android.synthetic.main.activity_bem_vindo.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BemVindoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bem_vindo)

        // Recupera o usuário (por exemplo, com id 1 para teste)
        obterUsuario(1)

        buttonEntrar.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    private fun obterUsuario(id: Int) {
        ApiClient.apiService.obterUsuario(id).enqueue(object : Callback<Usuario> {
            override fun onResponse(call: Call<Usuario>, response: Response<Usuario>) {
                if (response.isSuccessful) {
                    val usuario = response.body()
                    textViewBoasVindas.text = "Bem-vindo, ${usuario?.nome}!"
                } else {
                    Toast.makeText(this@BemVindoActivity, "Usuário não encontrado", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Usuario>, t: Throwable) {
                Toast.makeText(this@BemVindoActivity, "Erro de conexão", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

package com.example.cp3


import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @POST("usuarios")
    fun criarUsuario(@Body usuario: Usuario): Call<Usuario>

    @GET("usuarios/{id}")
    fun obterUsuario(@Path("id") id: Int): Call<Usuario>

    @PUT("usuarios/{id}")
    fun atualizarUsuario(@Path("id") id: Int, @Body usuario: Usuario): Call<Usuario>

    @DELETE("usuarios/{id}")
    fun deletarUsuario(@Path("id") id: Int): Call<Void>
}
package com.example.cp3

data class Usuario(
    val id: Int,
    val nome: String,
    val email: String,
    val senha: String
)